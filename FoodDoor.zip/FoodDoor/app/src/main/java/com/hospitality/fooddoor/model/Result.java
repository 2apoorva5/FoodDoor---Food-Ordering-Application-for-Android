package com.hospitality.fooddoor.model;

public class Result {

    public String message_id;
}
